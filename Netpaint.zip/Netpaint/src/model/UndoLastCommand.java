package model;

import server.NetpaintServer;


public class UndoLastCommand extends Command<NetpaintServer>{

	String clientName;
	
	public UndoLastCommand(String source) {
		super(source);
		this.clientName=source;
	}

	@Override
	public void execute(NetpaintServer executeOn) {
		executeOn.undoLast(clientName);
	}

}
