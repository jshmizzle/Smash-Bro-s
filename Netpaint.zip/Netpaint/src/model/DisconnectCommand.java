package model;

import server.NetpaintServer;

public class DisconnectCommand extends Command<NetpaintServer> {

	public DisconnectCommand(String source) {
		super(source);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void execute(NetpaintServer executeOn) {
		// TODO Auto-generated method stub
	}

}
