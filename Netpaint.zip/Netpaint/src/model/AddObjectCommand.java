package model;

import paintobject.PaintObject;
import server.NetpaintServer;

public class AddObjectCommand extends Command<NetpaintServer>{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4315111265186043677L;

	private PaintObject object;
	
	
	public AddObjectCommand(String username, PaintObject object) {
		super(username);
		this.object=object;
	}

	@Override
	public void execute(NetpaintServer executeOn) {
		executeOn.addObject(object);
	}

	@Override
	public void undo(NetpaintServer undoOn){
		undoOn.removeObject(object);
	}
}
